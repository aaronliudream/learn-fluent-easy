# 虚拟语气全攻克 · 整合说明

把这套虚拟语气专题课程（standalone HTML）整合进你的 `learn-fluent-easy` 项目。
全部改动都是**纯增量**——只**新增 1 个文件 + 修改 2 个文件**，零删除、零结构性改动。

## 你需要知道的关键事实

### ✅ 不会破坏你现有的网站
- **静态独立**：虚拟语气专题是一个**独立的 HTML 文件**，放在 `public/grammar-lab/` 下，它不参与你的 React 项目的打包。Vite build 时会原封不动复制到生产环境。
- **零依赖冲突**：HTML 自带 React UMD + Tailwind CDN，与你主项目完全隔离运行——不会和 supabase、shadcn、lovable 等任何东西冲突。
- **入口卡片是纯添加**：在 `GaokaoGrammar.tsx` 和 `JuniorGrammar.tsx` 各加了一个**新增的 `<section>`** 入口，没有删除/修改任何已有代码。
- **可一键回滚**：如果哪天不想要了，删除 `public/grammar-lab/` 目录 + 删除两个 tsx 里我加的 section 即可，跟没加过一样。

### 📍 放在哪里
- **高考英语 → 语法考点页面**（主要入口，因为内容覆盖了高考压轴的所有虚拟语气知识）
- **中考英语 → 语法专项页面**（次要入口，标注"选学/扩展"——前 3 关对应中考要求，后 6 关是高考预习）

### 🎯 没有遗漏内容
完整保留了你之前 7 轮迭代的所有改进：
- 9 关闯关式课程（L1 If I were you → L9 suggest/It's high time）
- 老师讲解（TTS + 字幕节奏，已修过"播放太快"的问题）
- 沉浸训练 + 反射点选
- 改写练习改成了 4 选 1 多选题（45 道题全部）
- 各种"反事实因果"、"逻辑主语错位"、"地道度三层判分"等深度反馈
- 加了"下一段"按钮 + → 键盘快捷键

---

## 安装步骤

### 第 1 步：把 3 个文件放到对应位置

把这个压缩包里的内容**直接覆盖/合并**到你的项目根目录：

```
你的项目根目录/
├── public/
│   └── grammar-lab/
│       └── subjunctive-mood.html         ← 新增（550 KB，独立专题课程）
└── src/
    └── pages/
        ├── GaokaoGrammar.tsx             ← 替换（加了 33 行入口卡片）
        └── JuniorGrammar.tsx             ← 替换（加了 31 行入口卡片）
```

> 注：`GaokaoGrammar.tsx` 和 `JuniorGrammar.tsx` 是**完整文件替换**，但它们仅相对于你下载的版本增加了入口卡片，其他代码完全没动。

### 第 2 步：本地验证（强烈建议）

```bash
npm install   # 如果还没装依赖
npm run dev
```

打开浏览器：
- 访问 `/gaokao/grammar` — 应该看到顶部多了一个"🎯 虚拟语气全攻克"卡片
- 访问 `/junior/grammar` — 同样能看到一个"🎯 虚拟语气全攻克（选学）"卡片
- 点击任一入口 — 应该打开 `/grammar-lab/subjunctive-mood.html`，独立的虚拟语气专题课程
- 课程页面右上角会有一个"← 返回主站"浮动按钮，点击回到 `/gaokao/grammar`

如果这些都正常，整合完成。

### 第 3 步：上传到 GitHub

```bash
git add public/grammar-lab/subjunctive-mood.html
git add src/pages/GaokaoGrammar.tsx
git add src/pages/JuniorGrammar.tsx
git commit -m "feat: 虚拟语气专题课程整合 (高考+中考双入口)"
git push
```

**上传到 GitHub 后会发生什么：**
- Lovable 会同步检测到代码变更（如果你的 Lovable 还在跟 GitHub 同步）
- 你的部署平台（Vercel / Netlify / 自部署）重新构建
- 静态 HTML 会被原样部署到 `https://你的域名/grammar-lab/subjunctive-mood.html`
- 用户访问 `/gaokao/grammar` 就能看到新入口

### 担心 Lovable 编辑会冲突吗？

**不会**，原因：
1. 这次新增的 `subjunctive-mood.html` 是个独立 HTML，不会被 Lovable 当作组件处理
2. 改的两个 tsx 文件，Lovable 后续如果要再改这两个页面也没问题——它会把我加的 section 当作普通的页面内容处理
3. 风险点：如果 Lovable 误删我加的 `<section>` 入口卡片，那整合就失效了。**建议**：在 Lovable 里改这两页时，留意一下是否动到了带 `特色专题 · 虚拟语气全攻克` 注释的代码块（我加了清晰的注释方便识别）。

---

## 如果想完全卸载

```bash
# 1. 删除独立专题
rm -rf public/grammar-lab/

# 2. 在 GaokaoGrammar.tsx 里删掉 "特色专题 · 虚拟语气全攻克" section（约 33 行）
# 3. 在 JuniorGrammar.tsx 里删掉 "选学专题 · 虚拟语气全攻克" section（约 31 行）

git commit -am "revert: 移除虚拟语气专题"
git push
```

---

## 后续优化方向（不是必须）

当前是**最稳健最快**的整合方式——零风险，但虚拟语气专题和你的主站是"两套设计语言"，独立运行。

如果以后想做**深度整合**（共享主站的 supabase mastery 跟踪、走 FSRS 间隔复习等），可以考虑：
1. 把 standalone HTML 拆成 React 组件，迁到 `src/pages/`
2. 把里面的题目数据迁到 supabase（参考 `gaokao_grammar_points` / `gaokao_grammar_questions` 表结构）
3. 接入现有的 mastery / FSRS 系统

但这是大工程，需要 1-2 周。现在的"静态独立 + 入口卡片"是过渡方案，先让用户能用起来。
